import React from 'react'

const Header = () => {
    return (
    <>
    <h5>Add an Item:</h5>
        <form action="" className="d-flex mx-auto row w-25">
            <label htmlFor="name">Name: </label>
            <input type="text" name="name" />
            <label htmlFor="cat">Category: </label>
            <input type="text" name="cat" />
            <label htmlFor="price">Price: </label>
            <input type="text" name="price" />
            <submit className="btn btn-info mt-3" onClick=""> Add Item</submit>       
        </form></>
    )
}

export default Header
